#include <stdio.h>

main(){
printf("testing hexpad");


}