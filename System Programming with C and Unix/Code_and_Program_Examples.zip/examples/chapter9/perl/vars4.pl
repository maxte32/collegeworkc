#!/usr/local/bin/perl
#
# demonstrate qw operator in perl (pg 325)
#
@a=qw / frog tiger turtle /;
print "@a[0] @a[1] @a[2]\n";
print "@a\n";
