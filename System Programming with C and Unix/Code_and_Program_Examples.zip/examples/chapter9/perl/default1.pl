#!/usr/local/bin/perl
#
# demonstrate using default variable name to read input
#
while (<STDIN>)
  {
  print "$_";
  }
