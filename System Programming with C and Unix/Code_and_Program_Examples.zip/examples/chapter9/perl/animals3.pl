#!/usr/local/bin/perl
#
# demonstrate printf operator in perl (pg 322)
#
$t=4;
$s="turtles";
$f=1.3;
printf "The %d %s move at %f kph ...\n",$t,$s,$f;
