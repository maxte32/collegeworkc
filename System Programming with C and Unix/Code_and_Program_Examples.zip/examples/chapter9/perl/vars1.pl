#!/usr/local/bin/perl
#
# demonstrate variables in perl (pgs 323-324)
#
# This is a comment
$x=3;
$y=7.2;
$z="14frog";
$a=$x+$y;
$b=$x+$z;
$c=$y+$z;
print "$a $b $c\n";
