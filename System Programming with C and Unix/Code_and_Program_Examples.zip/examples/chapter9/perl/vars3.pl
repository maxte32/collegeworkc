#!/usr/local/bin/perl
#
# demonstrate arrays in perl (pgs 324-325)
#
@a=("green frog", "orange tiger", "turtle");
print "@a[0] @a[1] @a[2]\n";
$f=@a[2];
print "$f\n";
