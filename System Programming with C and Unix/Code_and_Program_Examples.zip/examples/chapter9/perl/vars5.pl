#!/usr/local/bin/perl
#
# demonstrate the "use strict" statement in perl (pgs 325-326)
# this program will not run because the variable y is not declared
#
use strict;
my $x;
$x=3;
$y=7;
