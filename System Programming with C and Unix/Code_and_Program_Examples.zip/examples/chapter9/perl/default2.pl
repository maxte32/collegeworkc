#!/usr/local/bin/perl
#
# demonstrate use of default variable name (pg 328)
#
foreach (1..4)
  {
  $t+=$_;
  }
print "$t\n";
