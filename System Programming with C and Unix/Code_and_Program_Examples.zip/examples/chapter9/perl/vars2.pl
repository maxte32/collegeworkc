#!/usr/local/bin/perl
#
# demonstrate strings and string operators in perl (pg 324)
#
$x="turtle";
$y="frog" x 3;
$z=$x . $y;
print "$y $z\n";
