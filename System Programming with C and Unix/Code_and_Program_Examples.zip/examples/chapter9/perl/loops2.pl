#!/usr/local/bin/perl
#
# demonstrate the foreach loop in perl (pg 327)
#
foreach $i (1,2,3,4)
  {
  $t+=$i;
  }
print "$t\n";
