% demonstrate reading data from a file into an array (pg 338)
a=importdata('data1.txt')
