% array indices follow matrix notation conventions (pg 339)
% this example assumes vars1.m has been executed
b(3)=-2
c(3,1)=b(3)+2.4
