% demonstrate matrix operations in matlab (pgs 341-342)
a=[3 1 6]
b=[4 5 2]
c=a-b
