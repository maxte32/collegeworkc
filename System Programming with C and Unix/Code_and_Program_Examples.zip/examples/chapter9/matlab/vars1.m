% all variables in matlab are arrays (pg 339)
a=2
b=[3 1 5]
c=[6 2; 8 3; 14 42]
