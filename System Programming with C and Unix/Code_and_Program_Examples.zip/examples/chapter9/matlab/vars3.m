% demonstrate shortcuts for initializing arrays (pgs 339-340)
d=[0:0.2:1]
e=linspace(0,1,4)
