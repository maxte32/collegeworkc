% a simple matlab program (pg 335)
x=41;
y=3.3;
z=x/y;
disp (z);
