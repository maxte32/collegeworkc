% demonstrate loops in matlab (pg 341)
for i=1:3,
  disp('Hello');
end
i=0;
while i<3,
  disp('Goodbye');
i=i+1;
end
