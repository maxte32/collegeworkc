% another example of matrix operations in matlab (pg 343)
grades=[85 92 75 73 88 97 65 75]
A=grades>=90
B=grades>=80 & grades<90
