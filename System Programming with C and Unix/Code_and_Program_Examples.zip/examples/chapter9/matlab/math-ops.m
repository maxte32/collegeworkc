% demonstrate some built-in math functions in matlab (pgs 343-344)
a=[7 1 5 7];
sqrt(a)
cos(a)
sum(a)
mean(a)
std(a)
