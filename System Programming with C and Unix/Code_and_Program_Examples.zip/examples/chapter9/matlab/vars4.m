% array dimensions are automatically adjusted by matlab (pg 340)
% this example assumes vars2.m has been executed
b
b(6)=-12
b(2)=[]
b(2,1)=21
