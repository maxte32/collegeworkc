% demonstrate basic I/O in matlab (pg 335)
%
% This is a comment
x=input('Enter a number: ');
y=input('Second number: ');
z=x/y;
disp('Their ratio is ');
disp(z);
