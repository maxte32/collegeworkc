% demonstrate fprintf function in matlab (pg 337)
% assumes that io1.m has previously been executed
fprintf('The ratio of %f to %f is %.4f\n',x,y,z);
