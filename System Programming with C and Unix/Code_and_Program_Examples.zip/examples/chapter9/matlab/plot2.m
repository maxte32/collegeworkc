% demonstrate changing the line characteristics of a plot (pg 345)
x=0:0.01:1;
s=sin(x);
c=cos(x);
plot(s,c,'--k','LineWidth',4);
