% demonstrate creating a plot using matlab (pg 345)
x=0:0.01:1;
s=sin(x);
c=cos(x);
plot(s,c);
