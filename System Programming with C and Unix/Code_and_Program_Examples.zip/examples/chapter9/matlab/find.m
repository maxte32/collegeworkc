% demonstrate the find function in matlab (pg 343)
% assumes that matrix-ops2 has been previously executed
find(grades>=90)
