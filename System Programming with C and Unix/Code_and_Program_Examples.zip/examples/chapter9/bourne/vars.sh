#!/bin/sh
#
# Command line arguments in shell scripting (pg 309)
#
echo Run with $# arguments
echo First three command line arguments:
echo $0
echo $1
echo $2
echo PID is $$
