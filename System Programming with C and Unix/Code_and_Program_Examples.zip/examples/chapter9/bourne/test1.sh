#!/bin/sh
if test -f test?.sh ; then
  echo Exists
fi
