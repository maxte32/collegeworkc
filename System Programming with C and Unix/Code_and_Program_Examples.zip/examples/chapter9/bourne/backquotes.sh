#!/bin/sh
#
# Demonstrate use of backquotes to hold result of command (pg 315)
#
FILES=`ls`
echo $FILES

