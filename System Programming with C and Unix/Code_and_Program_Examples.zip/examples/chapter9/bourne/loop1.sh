#!/bin/sh
#
# Demonstrate for loop in shell scripting (pg 310)
#
for i in 1 2 5 tree frog
do
  echo "file${i}.txt"
done
