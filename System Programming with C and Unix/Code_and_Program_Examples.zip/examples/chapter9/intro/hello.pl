#!/usr/local/bin/perl
# Hello world in perl (pg 303)
print "Hello from perl\n";
