#!/urs/local/bin/perl
#
# Mis-spelling or mis-naming the path to perl can cause an error
# that looks like the script file is not found (pg 304)
#
print "Hello from perl\n";
