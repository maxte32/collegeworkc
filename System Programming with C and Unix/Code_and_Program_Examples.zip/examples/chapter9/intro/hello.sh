#!/bin/sh
# Hello world in Bourne shell (pg 305)
echo "Hello from sh"
