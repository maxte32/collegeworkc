#! /usr/bin/env python
# Hello world in python (pg 305)
print "Hello from python"
