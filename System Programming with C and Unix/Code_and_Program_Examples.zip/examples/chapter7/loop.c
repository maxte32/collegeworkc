
	/* Used to demonstrate process control at the shell (pgs 219-221) */

main()
{
while (1);
}

