
	/* Code for problem 10 (pg 209).  Which lines of code are valid,
	** and which are not? */

#define TOTAL 5
#define TURTLE 2;

typedef struct automobile {
			  char name[TOTAL];
			  int vehicle_id;
			  float kpg;
			  double *manuf_code;
			  } Entry;

Entry list[3],*passenger;
char who[7],a,*b;
double *d,d2;

	/* Starting here, which lines of code are valid? */
Entry.kpg=35.6;
list[1].kpg=39.1;
passenger->kpg=42.2;
who[TOTAL]=TURTLE
list[2].manuf_code=&d2;
list.kpg=28.7;
Entry->manuf_code=11;
list[3].name[0]=who[1];
list[TURTLE].vehicle_id=7;
list[TOTAL].vehicle_id=3;
passenger=&(list[0]); passenger->vehicle_id=3;

