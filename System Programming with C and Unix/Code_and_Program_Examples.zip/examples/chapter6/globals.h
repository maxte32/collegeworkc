
	/* This is my global variables file -- used in pre2.c. */

int	x;
double	y;
char	array[80];

