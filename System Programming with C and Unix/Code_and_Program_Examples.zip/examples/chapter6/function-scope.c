
	/* Demonstrate local (auto class) variable scope (pg 191) */
	/* All three of these variables have the same scope. */

int Function1(float e)
{
int x;
auto int y;

e=3.3;
x=7;
y=-2;
}

