
	/* Demonstrate the basics of using a library:
	** (1) include the header file
	** (2) link to the library file
	** (pgs 271-272) */

#include <stdio.h>
#include <math.h>

main()
{
double x,s;

s=8.0;
x=sqrt(s);
printf("%lf\n",x);
}

