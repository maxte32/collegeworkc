
	/* Include file for tris.c program */

struct Triangle {
	int	x;
	int	y;
	int	radius;
	int	angle;
	};

