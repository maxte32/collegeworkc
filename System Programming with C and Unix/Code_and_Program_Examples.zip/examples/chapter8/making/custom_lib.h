
	/* Header file for our simple library. */

int Largest(int,int);
void HelloWorld();
double SevenPointSeven();

#define SOME_MACRO	14

