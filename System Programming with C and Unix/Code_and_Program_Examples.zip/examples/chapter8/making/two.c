
	/* More simple functions to go into our sample library. */
	/* Demonstrates multiple object files in one library file. */

void HelloWorld()

{
printf("Hello world\n");
}


double SevenPointSeven()

{
return(7.7);
}

