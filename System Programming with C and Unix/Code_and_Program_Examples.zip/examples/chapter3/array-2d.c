
	/* How does a 2D array fit in memory?  Draw the memory map. (pg 77) */

#include <stdio.h>

main()
{
int a[3][2];

a[0][1]=7;
a[1][0]=13;
}
