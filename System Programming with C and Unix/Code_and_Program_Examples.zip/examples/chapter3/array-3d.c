
	/* How does a 3D array fit in memory?  Draw the memory map. (pg 78) */

#include <stdio.h>

main()
{
int b[2][3][4];

b[0][2][0]=7;
b[1][0][2]=13;
}
