
	/* This program shows basic string usage.
	** Draw the memory map. (pg 79) */

#include <stdio.h>

main()
{
char d[8];

d[0]='H'; d[1]='e'; d[2]='l'; d[3]='l'; d[4]='o';
d[5]='\0'; /* '\0' indicates the end of string */
}

