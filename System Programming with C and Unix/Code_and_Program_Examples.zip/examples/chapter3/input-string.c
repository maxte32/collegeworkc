
	/* This program shows how scanf() works with addresses.
	** Walk through the memory map. (pg 81) */

#include <stdio.h>

main()
{
int x;
float f;
char s[6];

scanf("%d",&x);
scanf("%f",&f);
scanf("%s",s);
}

