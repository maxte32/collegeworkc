
	/* This program demonstrates the bitwise not operator. (pg 59) */

#include <stdio.h>

main()
{
unsigned char a;

a=17;
a=~a;
printf("%d\n",a);
}
