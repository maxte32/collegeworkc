
	/* Draw the memory map for this code (pg 65) */

#include <stdio.h>

main()
{
char a,b,c;

a=7;
b=-13;
c=0;
}
