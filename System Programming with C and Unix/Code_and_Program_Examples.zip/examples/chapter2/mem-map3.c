
	/* Draw the memory map for this code.  Showing the bit patterns
	** emphasizes the differences in storage of "6" (pg 66) */

#include <stdio.h>

main()
{
char a;
short int b;
char c;

a=6;
b=13;
c='6';
}
