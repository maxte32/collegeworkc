
	/* Code for problem #10 in chapter 2 (pg 70) */

#include <stdio.h>

main()
{
int x=7;

x=(x|16)<<1;
printf("%d\n",x);
}

