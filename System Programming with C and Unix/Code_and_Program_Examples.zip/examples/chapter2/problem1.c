
	/* Code for problem 1 - draw the memory map (pg 68) */

#include <stdio.h>

main()
{
char c=35;
char d='G';
int x=-42;
float f=17.25;
int i=1099563008;
double a=17.25;
}
