
	/* This program demonstrates the bitwise and operator. (pg 60) */

#include <stdio.h>

main()
{
unsigned char a,b;

a=17;
b=22;
a=a & b;
printf("%d\n",a);
}
