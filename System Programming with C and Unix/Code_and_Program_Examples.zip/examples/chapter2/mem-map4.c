
	/* Draw the memory map for this code.  It can emphasize the
	** value of a loop counter after the loop is done (pg 67) */

#include <stdio.h>

main()
{
int i,n;

n=0;
for (i=1; i<=4; i++)
  n=n+i;
}
