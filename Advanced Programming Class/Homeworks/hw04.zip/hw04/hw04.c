#include <stdio.h>
#include "genlib.h"
#include "strlib.h"
#include "simpio.h"

typedef struct {
    string name;
    string title;
    string ssnum;
    double salary;
    int withholding;
} employeeRecordT;

typedef struct {
    string name;
    string title;
    string ssnum;
    double salary;
    int withholding;
} *employeeT;

typedef struct {
    employeeT *employees;
    int nEmployees;
} *payrollT;

static payrollT GetPayroll(employeeRecordT staff[], int nEmployees);
static void WeekPayroll(payrollT payroll);

/* Main program */

main()
{
	int nEmployees;
	printf("How many employees? ");
	nEmployees = GetInteger();
	employeeRecordT staff[nEmployees];

  	payrollT payroll;
    payroll = GetPayroll(staff, nEmployees);
    WeekPayroll(payroll);

	//doesnt work
	//free(staff);
	
	// doesn't work
	//int f = 0;
	//for (f; f<nEmployees; f++){
	//free(payroll->employees[f]);
	//}
	
	//didn't work
	//free(payroll->employees);
	//free(payroll);
	//the program compiles just fine....
	// i was able to print out the weekly payroll just fine, but then it goes into segmentation faults when i tried to fix it later and would not print out the payroll
	// i tried as much as i could to free and could not get it work. 
}


static payrollT GetPayroll(employeeRecordT staff[], int nEmployees)
//static payrollT GetPayroll()
{
  int i = 0;
	//employeeRecordT tempEmpRec;
	//printf("How many employees? ");
	//printf("Max is 10 ");
	//nEmployees = GetInteger();
	while (i < nEmployees){
	printf("Employee #%d:\n", (i+1));
	printf("\tName: ");
    //tempEmpRec.name = GetLine();
	staff[i].name = GetLine();
	printf("\tTitle: ");
    //tempEmpRec.title = GetLine();
	staff[i].title = GetLine();
	printf("\tSSNum: ");
    //tempEmpRec.ssnum = GetLine();
	staff[i].ssnum = GetLine();
	printf("\tSalary: ");
    //tempEmpRec.salary = GetReal();
	staff[i].salary = GetReal();
	printf("\tWithholding exemptions: ");
    //tempEmpRec.withholding = GetInteger();
	staff[i].withholding = GetInteger();
    //staff[i] = tempEmpRec;
	i++;
   }
	static payrollT payroll;
    payroll = New(payrollT);
    //payroll->employees = NewArray(nEmployees, employeeT);
    
	payroll->nEmployees = nEmployees;
    for (i = 0; i < nEmployees; i++){
        payroll->employees[i] = New(employeeT);
        payroll->employees[i]->name = staff[i].name;
        payroll->employees[i]->title = staff[i].title;
        payroll->employees[i]->ssnum = staff[i].ssnum;
        payroll->employees[i]->salary = staff[i].salary;
        payroll->employees[i]->withholding = staff[i].withholding;
		
    }
    return (payroll);
}

static void WeekPayroll(payrollT payroll)
{
	printf("\nWeekly Payroll\n");
	printf("Name\t\tGross Tax Net \n");
	printf("----------------------------------------------------------\n");
	int i;
	double tax, net;
    for (i = 0; i < payroll->nEmployees; i++) {
		tax = (((payroll->employees[i]->salary)-(payroll->employees[i]->withholding))*0.25);
		net = payroll->employees[i]->salary - tax;
        printf("%s\t\t%0.2lf - %0.2lf = %0.2lf\n", payroll->employees[i]->name, payroll->employees[i]->salary,tax,net);
    }
}

