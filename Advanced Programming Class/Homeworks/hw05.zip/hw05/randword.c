#include <stdio.h>
#include <stdlib.h>
#include "random.h"
#include "genlib.h"
#include "randword.h"

char words[20][20];

int InitDictionary(FILE *infile){
char scan;
int counter = 0, r = 0 , c = 0;
//FILE *infile = fopen("words.txt","r");
if(infile == NULL){
	printf("file name not correct\n");
	exit(1);
}

//while(fscanf(infile, "%s\n", &stringScan) != EOF){
//words[counter] = stringScan;
//while (fscanf(infile,"%s\n",&scan) != EOF){
while(feof(infile) == 0){
fscanf(infile, "%c", &scan); 
        if(scan =='\n'){
                words[r][c] = '\0';
                counter++;
				r++;
                c =0;
        }      
        words[r][c] = (scan);
        c++;    
        }

//fclose(infile);
return counter; 
}

char *ChooseRandomWord(int fileSize){
//static char *rWord;
//int fileSize = InitDictionary();
int r , i = 0;
Randomize();
r = rand() % 20;
//int randWord = rand()%fileSize;
char *rword = malloc(fileSize*sizeof(char));
	 while(words[r][i] != '\0'){
                        rword[i] = words[r][i+1];
                        i++;
                }
        return rword;
        free(rword);
//rWord = words[randWord]; 
//return rWord;
//return words[randWord];
}