// randword.h interface
#ifndef _randword_h
#define _randword_h

//includes
#include <stdio.h>
#include <stdlib.h>

extern char words[20][20];

// export
int InitDictionary(FILE *infile);
char *ChooseRandomWord(int fileSize);

#endif