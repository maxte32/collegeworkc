struct vector{
        float x;
        float y;
        float z;
};

struct particle{
        float mass;
        struct vector pos;
        struct vector vel;
};



