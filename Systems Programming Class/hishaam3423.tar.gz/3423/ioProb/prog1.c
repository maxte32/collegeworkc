#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define BUFSZ 1024

int main(int argc, char *argv[]){

}
