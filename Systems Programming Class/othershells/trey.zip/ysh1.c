#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

struct cmd
  {
    int redirect_in;     /* Any stdin redirection?         */
    int redirect_out;    /* Any stdout redirection?        */
    int redirect_append; /* Append stdout redirection?     */
    int background;      /* Put process in background?     */
    int piping;          /* Pipe prog1 into prog2?         */
    char *infile;        /* Name of stdin redirect file    */
    char *outfile;       /* Name of stdout redirect file   */
    char *argv1[10];     /* First program to execute       */
    char *argv2[10];     /* Second program in pipe         */
  };

int cmdscan(char *cmdbuf, struct cmd *com);


int main(){
	int stop = 0;
	char buf[1024];
	struct cmd command;
	int i;
	int fd[2];
	int fdin = fdout = 0;
	pid_t pid, pidBG;
	while(!stop){ 
		write(STDOUT_FILENO, ">", 1);
		if((gets(buf) == NULL)){
			continue;
		}
		else if(strcmp(buf, "exit") == 0){
			stop = 1;
			continue;
		}
	    	if (cmdscan(buf,&command)){
	    		printf("Illegal Format: \n");
			continue;
	    	}
		switch(pid = fork()){
			case -1:
				perror("fork");
				exit(-1);
			case 0:
				if (!command.piping && !command.redirect_in && !command.redirect_out && !command.redirect_append){
					execvp(command.argv1[0], command.argv1);
					perror("exec arg1");
					exit(-1);
				}
				if(command.redirect_out){
					if(command.redirect_append){
						if ( (fdout = open(command.outfile, O_WRONLY | O_APPEND | O_CREAT , 0600) ) == -1){
							perror("open fdout append");
							exit(-1);
						}
					}
					else{
						if ( (fdout = open(command.outfile, O_WRONLY | O_CREAT | O_TRUNC , 0600) ) == -1){
							perror("open fdout");
							exit(-1);
						}
					}
				}
				if (command.redirect_in){
					if( ( fdin = open(command.infile, O_RDONLY) ) == -1){
						perror("redirect in file error");
						exit(-1);
					}

				}
				if (command.piping){
					if (pipe(fd) == -1){
						perror("pipe");
						exit(-1);
					}
					if ((pidBG = fork()) == -1){
						perror("piping fork");
						exit(-1);
					}
					if(pidBG == 0){
						dup2(fd[1], STDOUT_FILENO);
						close(fd[1]);
						close(fd[0]);
						if(fdin){
							dup2(fdin, STDIN_FILENO);
							close(fdin);
						}
						execvp(command.argv1[0], command.argv1);
						perror("execv argv1");
						exit(-1);
					}
					else{
						dup2(fd[0], STDIN_FILENO);
						close(fd[0]);
						if(fdout){
							dup2(fdout, STDOUT_FILENO);
							
						}
						close(fd[1]);
						execvp(command.argv2[0], command.argv2);
						exit(-1);
					}
				}
				if (!command.piping){
					if (fdin){
						dup2(fdin, STDIN_FILENO);
						close(fdin);
					}
					if (fdout){
						dup2(fdout, STDOUT_FILENO);
						close(fdout);
					}
					execvp(command.argv1[0], command.argv1);
					perror("execvp argv1, 2call");
					break;
				}
			default:
				if (!command.background){ 
					if(waitpid(pid, NULL, 0) != pid){
						perror("waitpid error");
						exit(-1);
					}
				}
		}
	}
  exit(0);
}
