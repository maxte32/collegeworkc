#include <errno.h>
#include <math.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include "primelib.h"
#include "restart.h"
#include "uici.h"
#define MILLION 1000000L


static int adder = 0;
static long long increase = -1;
static int mutex = 1;
static int numtofind = 0;
static long long primepassed = 0;
static long long *primesfound;


void *find_prime(void *arg){
printf("here\n");
int *fd = (int*)arg;
int maxfd;
long long catcher = 0;
int lengthcheck = 0;

char buffer[1024];
char buff[1024];
int bytesread;
fd_set readset;

int totalbytes = 0;
int num;


//if ((*fd < 0) || (*fd >= FD_SETSIZE))
      //return 0;

   maxfd = *fd;                     /* find the biggest fd for select */
while(numtofind > 0){

wait(mutex);
       ++increase;   
       catcher = (primepassed + increase);
       sprintf(buffer, "%lld ",catcher);
       lengthcheck = strlen(buffer);
       signal(mutex);

   for ( ; ; ) { 
   
      FD_ZERO(&readset);
      FD_SET(*fd, &readset);

       

       
     
         
         if ( (bytesread =  r_write(*fd, buffer , lengthcheck )) != lengthcheck ){
            //return 1;
            
         }
         
      
      
      if (((num = select(maxfd+1, &readset, NULL, NULL, NULL)) == -1) &&
         (errno == EINTR)) 
         continue;
      //if (num == -1) 
         //return totalbytes;

      if (FD_ISSET(*fd, &readset)) {
         printf("here\n");
         bytesread = r_read(*fd,buff, 1024);
         if (bytesread <= 0) {
            perror("Failure getting message from server"); //return 1;
         }

         if (buff[0] == '0' ){
            //printf("Number is not Prime\n");
         } else if (buff[0] == '1'){
            //printf("Number is Prime\n");
            wait(mutex);   
            primesfound[adder] = (catcher);
            ++adder;
            --numtofind; 
            signal(mutex);
         }
 
         //break;

      }
   }
}

   close(*fd);   


//    

//   while(numtofind > 0){

 //    

      /* connect to server */


      /* send prime */

      /* get result */

      /* close connection */



/*      
      if ( isPrimeLongLong( catcher )){
         
      }
*/



 //  }
   
   pthread_exit((void*) arg);
}


int main(int argc, char *argv[]) {

/* reorganize */

   char buff[1024];
   int bytescopied;
   int bytesread;
   //int communfd;
   int flag = 0;    

   int i = 0;
   int i2 = 0;
   int lengthcheck = 0;
   int lengthcheck2 = 0;

   u_port_t portnumber;
 
   int maxfd;
   int num;
   fd_set readset;
   int totalbytes = 0;


   pthread_attr_t attr;
   int c;
   int d;
   int error;
   //int fd;
   long long primeparameter;
   int numfind;
   int numthreads;	

   int lengthcheck3;
   void *status;
   long long t;  
   long timedif;
   double timedifout;
   struct timeval tpend;
   struct timeval tpstart;


   int hostremain = 0;

   if (argc < 5) {
      fprintf(stderr, "Usage: %s *prime* *number of primes to find* *port* *host,host,host*\n", argv[0]);
      return 1;
   }

   if ( strlen(argv[1]) > 25  ) {
      fprintf(stderr, " Please do not try to buffer overflow\n");
      return 1;
   }   

   if ( strlen(argv[2]) > 25 ) {
      fprintf(stderr, " Please do not try to buffer overflow\n");
      return 1;
   }

   if ( strlen(argv[3]) > 25 ){
      fprintf(stderr, " Please do not try to buffer overflow\n");
      return 1;
   }

   if ( strlen(argv[4]) > 25 ){
      fprintf(stderr, " Please do not try to buffer overflow\n");
      return 1;
   }

   int numhost = 0;

   if (argc > 5){
      hostremain = argc - 5;
      for (i = 0; i < hostremain; i++){
            if ( strlen(argv[(5 + i)]) > 25 ){
               fprintf(stderr, " Please do not try to buffer overflow\n");
            return 1;
         }

      }
         
   }
    
      numhost = hostremain + 1;
   
   lengthcheck = strlen(argv[1]);
   lengthcheck2 = strlen(argv[2]);

   for ( i = 0; i < lengthcheck; i++){
      if ( isalpha(argv[1][i]) ){
         fprintf(stderr, " Please only enter digits \n");
         return 1;         
      } else if ( isdigit(argv[1][i])  ) {
         
         
      } else {
         fprintf(stderr," Please only enter digits \n");
         return 1;
      }         
   }

   for ( i = 0; i < lengthcheck2; i++){
      if ( isalpha(argv[2][i]) ){
         fprintf(stderr, " Please only enter digits \n");
         return 1;         
      } else if ( isdigit(argv[2][i])  ) {
         
         
      } else {
         fprintf(stderr," Please only enter digits \n");
         return 1;
      }         
   }

   char *hostnames[numhost];
   int fd[numhost*4];


   /* Get host names */

      //hostremain = argc - 5;
      for (i = 0; i < numhost; i++){
         hostnames[i] = argv[(4 + i)];
         /*   
         if ( strlen(argv[(5 + i)]) > 25 ){
               fprintf(stderr, " Please do not try to buffer overflow\n");
            return 1;
         }
         */
         printf("hostname :%s \n", hostnames[i]);
      }
    
   i2 = 0;
   /* fix here change the stuff around */
   portnumber = (u_port_t)atoi(argv[3]);
   for (i = 0; i < numhost*4; i++){
       
       printf("%d\n",i2);
       if ( ((i % 4 ) == 0) && ( i > 0 ) ) {
         i2 += 1;
         
      }      
      printf("here\n");
      if ( (fd[i] = u_connect(portnumber, argv[(4+i2)])) == -1 ) {
         perror("Failed to establish connection");
         //return 1;
      }
      
   }
printf("here\n");


   /* Set attributes */

   /* Get the time */

   /* Make the threads */

   /* Join the threads */

   /*  */


   int numhostthreads = (numhost) * 4;

   primeparameter = atoll(argv[1]);
   numfind = atoi(argv[2]);
   //numthreads = atoi(argv[3]);	

   long long primegreater[numfind];
   primesfound = primegreater;
   
   pthread_t thread[numhostthreads];
   int threadfd[numhostthreads];
   
   primepassed = primeparameter;
   numtofind = numfind;
   
   /* Initialize and set thread detached attribute */
   pthread_attr_init(&attr);
   pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
   pthread_attr_setscope(&attr, PTHREAD_SCOPE_SYSTEM); 
   
   /* get time of day */
   if (gettimeofday(&tpstart, NULL)) {
      fprintf(stderr, "Failed to get start time\n");
      return 1;
   }

   i2 = 0;
   /* call all threads */
   for (i = 0; i < numhostthreads; i++){
      printf("%d\n",i2);
      if ( ((i % 3 ) == 0) && ( i > 0 ) ) {
         //i2 += 1;
         
      }
      printf("here\n");
      if (error = pthread_create(&thread[i], &attr, find_prime, &fd[i])){
            fprintf(stderr, "Failed to create thread: %s\n", strerror(error));
      }
   }

   /* join the threads  */
   /* Free attribute and wait for the other threads */
   pthread_attr_destroy(&attr);
   for( i=0; i<numthreads; i++ ) {
      if ( error  = pthread_join(thread[i], &status) )
         fprintf(stderr, " Failed to join thread %s\n", strerror(error));   
   }

   if (gettimeofday(&tpend, NULL)) {
      fprintf(stderr, "Failed to get end time\n");
      return 1;
   }

   /* Sort the array */
/*
   for (c = 1 ; c <= adder - 1; c++) {
      d = c;
 
      while ( d > 0 && primesfound[d] < primesfound[d-1]) {
      t          = primesfound[d];
      primesfound[d]   = primesfound[d-1];
      primesfound[d-1] = t;
 
      d--;
    }
  }
*/

   /* standard output */ 
   printf("%lld\n", primeparameter);
   
   for (i = 0; i < numfind; i++){
      //printf("%lld\n",primesfound[i]);
   }
   
   /* standard err  */ 
   //fprintf(stderr,"%lld\n", primeparameter);
   //for (i = 0; i < numfind; i++){
   //   fprintf(stderr,"%lld\n",primesfound[i]);
   //}
   
   timedif = MILLION*(tpend.tv_sec - tpstart.tv_sec) + tpend.tv_usec - tpstart.tv_usec;
   timedifout = timedif/1000000.0;

   fprintf(stderr,"%.5lf\n", timedifout);
   
   pthread_exit(NULL);

   return 0;

}


/*  */

   /* Connection made */
/*

   portnumber = (u_port_t)atoi(argv[3]);
   if ((communfd = u_connect(portnumber, argv[4])) == -1) {
      perror("Failed to establish connection");
      return 1;  
   }

   */

