#ifndef PRIMELIB_H
#define PRIMELIB_H

int isPrimeInt(int num);
int isPrimeLongLong(long long num);

#endif
